package bcc.gui;

import java.awt.*;
import javax.swing.*;

public class ButtonPanel extends JPanel {

	private GridLayout layout = new GridLayout(0,1,5,5);
	private JButton elephant = new JButton("Elephant");
	private JButton tiger = new JButton("Tiger");
	private JButton bear = new JButton("Bear");
	
	public ButtonPanel(ZooFrame frame) {
		this.setLayout(layout);
		add(elephant);
		add(tiger);
		add(bear);
		elephant.addActionListener(frame);
		tiger.addActionListener(frame);
		bear.addActionListener(frame);
	}
}
