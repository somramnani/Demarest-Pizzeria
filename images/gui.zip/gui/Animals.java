package bcc.gui;

import java.util.HashMap;
import java.util.Map;

public class Animals {
	private Map<String, String> picMap = new HashMap<String, String>();
	private Map<String, String> textMap = new HashMap<String, String>();
	
	public Animals() {
		picMap.put("Elephant", "elephant.jpg");
		picMap.put("Tiger", "tiger.jpeg");
		picMap.put("Bear", "bear.jpg");
		
		textMap.put("Elephant", "Elephants are large mammals of the family Elephantidae and the order Proboscidea.\n Three species are currently recognized:\n the African bush elephant (Loxodonta africana), \nthe African forest elephant (L. cyclotis), \nand the Asian elephant (Elephas maximus).\n Elephants are scattered throughout sub-Saharan Africa, South Asia, and Southeast Asia.\n Elephantidae is the only surviving family of the order Proboscidea;\n other, now extinct, members of the order include deinotheres, gomphotheres, mammoths, and mastodons.");
		textMap.put("Bear", "Bears are carnivoran mammals of the family Ursidae.\n They are classified as caniforms, or doglike carnivorans.\n Although only eight species of bears are extant, they are widespread,\n appearing in a wide variety of habitats throughout the Northern Hemisphere and partially in the Southern Hemisphere.");
		textMap.put("Tiger", "The tiger (Panthera tigris) is the largest cat species,[4]\n most recognizable for their pattern of dark vertical stripes on reddish-orange fur with a lighter underside.\n The species is classified in the genus Panthera with the lion, leopard, jaguar, and snow leopard.\n Tigers are apex predators, primarily preying on ungulates such as deer and bovids.");
	}
	
	public String getText(String name) {
		return textMap.get(name);
	}
	
	public String getPic(String name) {
		return picMap.get(name);
	}
}
