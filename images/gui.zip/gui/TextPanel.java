package bcc.gui;

import java.awt.FlowLayout;

import javax.swing.*;

public class TextPanel extends JPanel {

	private FlowLayout layout = new FlowLayout();
	private JTextArea label = new JTextArea();
	private JPanel panel = new JPanel();
	private JScrollPane scroll = new JScrollPane(panel, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

	public TextPanel(String text) {
		label.setText(text);
		layout.setAlignment(FlowLayout.CENTER);
		this.setLayout(layout);
		//panel.setSize(200, 100);
		panel.add(label);
		this.add(panel);
	}
	
	public void setText(String text) {
		label.setText(text);
	}
}
