package bcc.gui;

import java.awt.*;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class BannerPanel extends JPanel {

	private FlowLayout layout = new FlowLayout();
	private JLabel label = new JLabel("Bergen County Zoo");

	public BannerPanel() {
		layout.setAlignment(FlowLayout.CENTER);
		this.setLayout(layout);
		this.add(label);
	}

}
