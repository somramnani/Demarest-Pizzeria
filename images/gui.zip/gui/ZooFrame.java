package bcc.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class ZooFrame extends JFrame implements ActionListener {

	private Container content = getContentPane();
	final int WIDTH = 800;
	final int HEIGHT = 500;
	private BannerPanel banner = new BannerPanel();
	private TextPanel textDescription = new TextPanel("Animal stuff");
	private ButtonPanel buttons = new ButtonPanel(this);
	private PicturePanel pic = new PicturePanel();
	private Animals animals = new Animals();

	public ZooFrame() {
		super("BC Zoo");
		this.setSize(WIDTH, HEIGHT);
		textDescription.setText(animals.getText("Elephant"));
		content.setLayout(new BorderLayout());
		content.add(banner, BorderLayout.NORTH);
		content.add(buttons, BorderLayout.WEST);
		content.add(textDescription, BorderLayout.SOUTH);
		content.add(pic, BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public static void main(String[] args) {
		ZooFrame frame = new ZooFrame();
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		JButton b = (JButton)o;
		String name = b.getText();
		String pic = animals.getPic(name);
		String text = animals.getText(name);
		this.pic.setPic(pic);
		this.textDescription.setText(text);
	}

}
 