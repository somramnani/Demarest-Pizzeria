package bcc.gui;

import java.awt.FlowLayout;

import javax.swing.*;


public class PicturePanel extends JPanel {
	private ImageIcon pic = new ImageIcon("elephant.jpg");
	private JLabel label = new JLabel(pic);
	private FlowLayout layout = new FlowLayout();

	public PicturePanel() {
		layout.setAlignment(FlowLayout.CENTER);
		this.setLayout(layout);
		this.add(label);
	}
	
	public void setPic(String name) {
		pic = new ImageIcon(name);
		label.setIcon(pic);
	}
}
